package com.example.calculoohm

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val edttensao = findViewById<EditText>(R.id.tensao)
        val edtresistencia = findViewById<EditText>(R.id.resistencia)
        val edtcorrente = findViewById<EditText>(R.id.corrente)
        val btnEnviar = findViewById<Button>(R.id.button)
        val tvresultado = findViewById<TextView>(R.id.tvresultado)

        btnEnviar.setOnClickListener{
            val valortensao = edttensao.text.toString().replace(',', '.').toDoubleOrNull()
            val valorresistencia = edtresistencia.text.toString().replace(',', '.').toDoubleOrNull()
            val valorcorrente = edtcorrente.text.toString().replace(',', '.').toDoubleOrNull()
            val resultado = tvresultado.text.toString().replace(',', '.').toDoubleOrNull()

            if (valorcorrente != null && valorcorrente > 0 && valorresistencia != null && valorresistencia > 0) {
                val resultensao = valorresistencia * valorcorrente
                tvresultado.text = "Resultado: $resultensao"
            } else if (valortensao != null && valortensao > 0 && valorresistencia != null && valorresistencia > 0) {
                val resulcorrente = (valortensao / valorresistencia) * 1000
                tvresultado.text = "Resultado: $resulcorrente"
            } else if (valortensao != null && valorcorrente != null && valorcorrente > 0) {
                val resulresistencia = valortensao / valorcorrente
                tvresultado.text = "Resultado: $resulresistencia"
            } else {
               tvresultado.text = "Valores inválidos"
            }
        }
    }
}