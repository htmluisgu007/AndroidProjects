package com.example.calculadora

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etNumero1 = findViewById<EditText>(R.id.etNumero1)
        val etNumero2 = findViewById<EditText>(R.id.etNumero2)
        val tvResultado = findViewById<TextView>(R.id.tvResultado)
        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnSub = findViewById<Button>(R.id.btnSub)
        val btnMult = findViewById<Button>(R.id.btnMult)
        val btnDiv = findViewById<Button>(R.id.btnDiv)

        btnAdd.setOnClickListener {
            val num1 = etNumero1.text.toString().toDoubleOrNull()
            val num2 = etNumero2.text.toString().toDoubleOrNull()

            if (num1 != null && num2 != null) {
                val result = num1 + num2
                tvResultado.text = "Resultado: $result"
            } else {
                tvResultado.text = "Por favor, insira números válidos"
            }
        }

        btnSub.setOnClickListener {
            val num1 = etNumero1.text.toString().toDoubleOrNull()
            val num2 = etNumero2.text.toString().toDoubleOrNull()

            if (num1 != null && num2 != null) {
                val result = num1 - num2
                tvResultado.text = "Resultado: $result"
            } else {
                tvResultado.text = "Por favor, insira números válidos"
            }
        }

        btnMult.setOnClickListener {
            val num1 = etNumero1.text.toString().toDoubleOrNull()
            val num2 = etNumero2.text.toString().toDoubleOrNull()

            if (num1 != null && num2 != null) {
                val result = num1 * num2
                tvResultado.text = "Resultado: $result"
            } else {
                tvResultado.text = "Por favor, insira números válidos"
            }
        }

        btnDiv.setOnClickListener {
            val num1 = etNumero1.text.toString().toDoubleOrNull()
            val num2 = etNumero2.text.toString().toDoubleOrNull()

            if (num1 != null && num2 != null) {
                if (num2 != 0.0) {
                    val result = num1 / num2
                    tvResultado.text = "Resultado: $result"
                } else {
                    tvResultado.text = "Divisão por zero não é permitida"
                }
            } else {
                tvResultado.text = "Por favor, insira números válidos"
            }
        }
    }
}
